#include "light.h"
#include "phong_shader.h"
#include "ray.h"
#include "render_world.h"
#include "object.h"

#include <algorithm>
#include <math.h>
#include <iostream>
using namespace std;

vec3 Phong_Shader::
Shade_Surface(const Ray& ray,const vec3& intersection_point,
    const vec3& normal,int recursion_depth) const
{
    vec3 color;
   // TODO; //determine the color
    
    vec3 a;
    vec3 sh;
    vec3 re;
    vec3 d;
    vec3 s;
    Hit in;
    Light* curr;
    a=color_ambient*world.ambient_color*world.ambient_intensity;
    for(int i=0; i<world.lights.size(); i++){   //here is to calculate the diffuse part and spectral part
	    curr=world.lights[i];
	    sh=curr->position-intersection_point;
	    Ray shadow_ray(intersection_point, sh.normalized());
	    in=world.Closest_Intersection(shadow_ray);
	    re=(sh-2*dot(sh, normal.normalized())*normal).normalized();
            double m=max(dot(ray.direction, re),0.0);
            double n=max(dot(normal.normalized(), shadow_ray.direction), 0.0);
	    if(!world.enable_shadows || (world.enable_shadows && (!in.object || in.dist >= sh.magnitude()))){         //to choose using diffuse and specular or not using
		    s=s+color_specular*curr->Emitted_Light(-sh)*pow(m, specular_power);
		    d=d+color_diffuse*curr->Emitted_Light(-sh)*n;	
    	}
    }
    color = a + d + s;

    return color;
}
