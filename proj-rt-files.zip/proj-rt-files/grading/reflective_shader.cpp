#include "reflective_shader.h"
#include "ray.h"
#include "render_world.h"

vec3 Reflective_Shader::
Shade_Surface(const Ray& ray,const vec3& intersection_point,
    const vec3& normal,int recursion_depth) const
{
    vec3 color;
    TODO; // determine the color
    
    vec3 a=shader->Shade_Surface(ray, intersection_point,normal,recursion_depth);
    color=(1-reflectivity)*a;
    if(recursion_depth<world.recursion_depth_limit){
	    vec3 b=ray.endpoint-intersection_point;
        vec3 c=(2*dot(b,normal)*normal-b).normalized();
	    Ray d(intersection_point, c);
	    color=color+reflectivity*world.Cast_Ray(d, recursion_depth+1);
    }

    return color;
}
